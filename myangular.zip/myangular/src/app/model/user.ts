export class User {
    id: number;
    name: String;
    password: String;
    email: String;

    constructor(name, password, email){
        this.name = name;
        this.password =  password;
        this.email = email;
    }
    setName(name){
        this.name = name;
    }
    
    setPassword(password){
        this.password = password;
    }

    setEmail(email){
        this.email = email;
    }
}
