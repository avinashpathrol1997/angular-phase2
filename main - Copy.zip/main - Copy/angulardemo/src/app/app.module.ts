import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RegComponent } from './reg/reg.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { UploadComponent } from './upload/upload.component';
import { GalleryComponent } from './gallery/gallery.component';
import { ProfileComponent } from './profile/profile.component';
import { FollowersComponent } from './followers/followers.component';
import { BlockedComponent } from './blocked/blocked.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    RegComponent,
    WelcomeComponent,
    UploadComponent,
    GalleryComponent,
    ProfileComponent,
    FollowersComponent,
    BlockedComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot([
      {
        path: 'login',
        component: LoginComponent
      },
      
      {
        path: 'reg',
        component: RegComponent
      },
      
      {
        path: '',
        component: HomeComponent
      },
      {
        path: 'welcome',
        component: WelcomeComponent
      },
      {
        path: 'gallery',
        component: GalleryComponent
      },
      {
        path: 'profile',
        component: ProfileComponent
      },
      {
        path: 'upload',
        component: UploadComponent
      },
      {
        path: 'followers',
        component: FollowersComponent
      },
      {
        path: 'blocked',
        component: BlockedComponent
      }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
